﻿namespace RunGroopWebApp.Data.Enum
{
    public enum RaceCategory
    {
        Marthon,
        Ultra,
        Fivek,
        Tenk,
        HalfMarathon
    }
}
