﻿namespace RunGroopWebApp.Data.Enum
{
    public enum ClubCategory
    {
        RoadRunner,
        City,
        Trail,
        Endurance
    }
}
